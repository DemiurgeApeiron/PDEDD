En este programa se suma el mismo numero con diferentes algoritmos,
sumaIterativa recibe un entero que suma los numeros anteriores a este
esta ocupa un metodo iterativo el cual es un for loop

tiene una complejidad temporal de O(n)

los resultados para este son:

suma iterativa con 3: 6
suma iterativa con 4: 10
suma iterativa con 5: 15
suma iterativa con 6: 21

sumaRecursiva este recibe un entero que suma los numeros anteriores a este
este ocupa un metodo recursivo con el metodo n + sumaRecursiva(n-1)

tiene una complejidad temporal de O(n)

los resultados para este son:

suma recursiva con 3: 6
suma recursiva con 4: 10
suma recursiva con 5: 15
suma recursiva con 6: 21

sumaDirecta este recibe un entero que suma los numeros anteriores a este
este ocupa un metodo directo con la ecuasion n*(n+1)/2

tiene una complejidad temporal de O(1)

los resultados para este son:

suma directa con 3: 6
suma directa con 4: 10
suma directa con 5: 15
suma directa con 6: 21
